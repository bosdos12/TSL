# TSL
Turkish Sign Language
This project aims to popularise TSL which has very little published information and doesn't allow Turkish deaf people to effectively speak in Turkey itself. This app will be teaching TSL in both English and Turkish languages.

To understand how bad the situation with Turkish sign language is you can watch the following video:
https://www.youtube.com/watch?v=oeqcvmxGJfw&feature=youtu.be&list=LL1myDLXIJBVylUivV8VoxNw

